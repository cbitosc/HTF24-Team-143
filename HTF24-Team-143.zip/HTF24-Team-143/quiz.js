// Quiz questions array
const questions = [
    {question:"which is called the self style breathing in anime demon slayer ?",choices:["thunder breathing","serpent breathing","beast breathing","mist breathing"],correct:"beast breathing"},{question:"in attack on Titan anime, what are the large creatures called?",choices:["ghosts","demons","Titans","humans"],correct:"Titans"},
    {question:"in jujutsu kaisen anime, what is gojo's Domain expansion called?",choices:["malevolent shrine","unlimited void","chimera shadow garden","self-embodiment of perfection "],correct:"unlimited void"},
    {question:"how old ismuzan from anime demon slayer?",choices:["1000+","500+","200+","100+"],correct:"1000+"},
    {question:"who is the strongest?",choices:["tanjiro","luffy","Naruto","gojo"],correct:"gojo"},
    {question:"who is the strongest villain ",choices:["sukuna","orochimaru","muzan","marshell D.teach"],correct:"sukuna"},
    { question: "What is the anime death note about?", choices: ["time travel", "friendship", "drama", "a book in which if a name is written, then person will die"], correct: "a book in which if a name is written, then person will die" },
    { question: "What is Naruto's favourite food", choices: ["biryani", "raman", "chapathi", "mutton"], correct: "raman" },
    { question: "What is the capital of Japan?", choices: ["Tokyo", "Beijing", "Seoul", "Bangkok"], correct: "Tokyo" },
];

let currentQuestionIndex = 0;
let score = 0;

// DOM elements
const questionContainer = document.getElementById("question-container");
const questionElement = document.getElementById("question");
const choicesContainer = document.getElementById("choices");
const nextButton = document.getElementById("next-button");
const resultContainer = document.getElementById("result-container");
const finalScoreElement = document.getElementById("final-score");
const usernameInput = document.getElementById("username");
const saveScoreButton = document.getElementById("save-score");
const leaderboardElement = document.getElementById("leaderboard");

// Load question
function loadQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesContainer.innerHTML = "";
    
    currentQuestion.choices.forEach(choice => {
        const button = document.createElement("button");
        button.textContent = choice;
        button.classList.add("choice");
        button.addEventListener("click", () => selectAnswer(choice));
        choicesContainer.appendChild(button);
    });
}

// Select answer and validate
function selectAnswer(selectedChoice) {
    const correctAnswer = questions[currentQuestionIndex].correct;
    if (selectedChoice === correctAnswer) {
        score++;
    }
    nextButton.disabled = false;
}

// Move to next question or show result
 nextButton.addEventListener("click", () => 
     {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
        nextButton.disabled = true;
    } else {
        showResult();
    }
});

// Show result and enable score saving
function showResult() {
    questionContainer.style.display = "none";
    resultContainer.style.display = "block";
    finalScoreElement.textContent = score;
}

// Save score to leaderboard
saveScoreButton.addEventListener("click", () => {
    const username = usernameInput.value.trim();
    if (username) {
        saveToLeaderboard(username, score);
        displayLeaderboard();
        usernameInput.value = "";
    }
});

// Save leaderboard to local storage
function saveToLeaderboard(username, score) {
    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboard.push({ name: username, score: score });
    leaderboard.sort((a, b) => b.score - a.score);
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
}

function displayLeaderboard() {
    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboardElement.innerHTML = "";

    leaderboard.forEach(entry => {
        const li = document.createElement("li");
        li.textContent = `${entry.name}: ${entry.score}`;
        leaderboardElement.appendChild(li);
    });
}
loadQuestion();
displayLeaderboard();